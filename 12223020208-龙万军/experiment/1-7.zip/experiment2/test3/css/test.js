let phrase = "nihao";

function call(name) { 
    alert(phrase);
 }


phrase = "nope";

call("John");
// function call1() { 
//     let count = 0;
//     return function call2() { 
//         let count = 1;
//         return count++;
//     }
//  }


//  let test = call1();

//  alert(test());