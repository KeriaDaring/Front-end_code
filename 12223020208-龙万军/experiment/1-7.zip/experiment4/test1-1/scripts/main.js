

// function print_char() {
//     for(let i = 1; i <= 5; i++) {
//         for(let j = 1; j <= i; j++) {
//             document.write("*");
//         }
//         document.write("<br>");
//     }
// }

for(let i = 1; i <= 5; i++) {
    for(let j = 1; j <= i; j++) {
        document.write("*");
    }
    document.write("<br>");
}

