function gotoCNBlogs() {
    window.open("http://www.cnblogs.com");
}

window.setTimeout("gotoCNBlogs();", 5000);