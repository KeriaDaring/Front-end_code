let price = "235.4"
let num = "5"

let sum;

sum = parseFloat(price) * parseInt(num);

window.alert("您将购买的商品的单价为“" + price + "元“" + "您将有购买“" +
            num + "个“,金额为“" + sum + "元”");